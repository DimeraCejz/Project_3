# import pygame
#
#
# pygame.init()
# screen = pygame.display.set_mode((450, 600))
#
#
# def draw():
#     screen.fill




#  ФИГНЯ!!!!!!!!!!!!!!!!!